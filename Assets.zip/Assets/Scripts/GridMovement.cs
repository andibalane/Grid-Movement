using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Tilemaps;

public class GridMovement : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private Vector2 startWorld = new Vector2(0.5f, -0.5f);
    [SerializeField] private bool isRepeatedMovement = false;
    [SerializeField] private float moveDuration = 0.18f;
    [SerializeField] private float gridSize = 1f;

    [Header("Collision (Impassable)")]
    [SerializeField] private LayerMask wallMask;
    [SerializeField] private Vector2 colliderSize = new Vector2(0.8f, 0.8f);

    [Header("Tilemap (Reference)")]
    [SerializeField] public Tilemap tilemap;

    private Rigidbody2D rb;
    public bool IsMoving { get; private set; }
    public Vector2Int LastFacingDir { get; set; } = Vector2Int.down;
    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    public event Action OnMoveStarted;
    public event Action OnMoveEnded;


private void Start()
{
    if (gridSize <= 0f) gridSize = 1f;
    Vector3 p = new Vector3(startWorld.x, startWorld.y, transform.position.z);

    if (rb != null)
        rb.position = p;
    else
        transform.position = p;
}


    private void Update()
    {
        if (IsMoving) return;

        Func<KeyCode, bool> pressed = isRepeatedMovement ? (Func<KeyCode, bool>)Input.GetKey
                                                         : Input.GetKeyDown;

        Vector2Int dir = Vector2Int.zero;

        //Keypress function (WASD  & Arrows)
        if (pressed(KeyCode.UpArrow)||pressed(KeyCode.W)) dir = Vector2Int.up;
        else if (pressed(KeyCode.DownArrow) || pressed(KeyCode.S)) dir = Vector2Int.down;
        else if (pressed(KeyCode.LeftArrow) || pressed(KeyCode.A)) dir = Vector2Int.left;
        else if (pressed(KeyCode.RightArrow) || pressed(KeyCode.D)) dir = Vector2Int.right;

        // If a direction was pressed
        if (dir != Vector2Int.zero)
        {
            LastFacingDir = dir;

            //and they can move/there's no obstacle, start moving
            if (CanStep(dir))
            {
                StartCoroutine(MoveOneTile(dir));
            }
            else
            {
            }
        }
    }

    //Check if the adjacent tile can be moved to
    public bool CanStep(Vector2Int dir)
    {
        Vector2 start = transform.position;
        Vector2 end = start + ((Vector2)dir * gridSize);

        Collider2D hit = Physics2D.OverlapBox(end, colliderSize, 0f, wallMask);
        return hit == null;
    }


    public IEnumerator MoveOneTile(Vector2Int dir)
    {
        IsMoving = true;
        OnMoveStarted?.Invoke();

        Vector3 start = transform.position;
        Vector3 end = start + (Vector3)((Vector2)dir * gridSize);

        float t = 0f;
        while (t < moveDuration)
        {
            t += Time.deltaTime;
            float percent = Mathf.Clamp01(t / moveDuration);
            transform.position = Vector3.Lerp(start, end, percent);
            yield return null;
        }

        transform.position = end;

        Vector3 snapped = new Vector3(
            Mathf.Floor(end.x) + 0.5f,
            Mathf.Floor(end.y) + 0.5f,
            end.z
        );
        transform.position = snapped;

        IsMoving = false;
        OnMoveEnded?.Invoke();

        CheckTileEffect();
    }

    public IEnumerator ForceMove(Vector2Int dir)
    {
        if (IsMoving) yield break; // don�t interrupt another move
        if (!CanStep(dir)) //When player  is blocked by an obstacle, 
        {
            //stop auto-move so that the player can choose a new direction
            LastFacingDir = Vector2Int.zero;
            yield break; ;
        } 

        IsMoving = true;
        OnMoveStarted?.Invoke();

        Vector3 start = transform.position;
        Vector3 end = start + (Vector3)((Vector2)dir * gridSize);

        float t = 0f;
        while (t < moveDuration)
        {
            t += Time.deltaTime;
            float percent = Mathf.Clamp01(t / moveDuration);
            transform.position = Vector3.Lerp(start, end, percent);
            yield return null;
        }

        Vector3 snapped = new Vector3(
            Mathf.Floor(end.x) + 0.5f,
            Mathf.Floor(end.y) + 0.5f,
            end.z
        );
        transform.position = snapped;

        IsMoving = false;
        OnMoveEnded?.Invoke();

        CheckTileEffect();
    }

    private void CheckTileEffect()
    {
        Vector3Int cell = tilemap.WorldToCell(transform.position);
        TileBase tile = tilemap.GetTile(cell);

        if (tile is ArrowTiles arrowTile)
        {
            arrowTile.ApplyEffect(this); 
        }
        if (tile is IceTiles iceTile)
        {
            iceTile.ApplyEffect(this);
        }
        else
        {
            LastFacingDir = Vector2Int.zero;
        }
    }

    //For Teleportation Portals
    public void CancelMovement()
    {
        StopAllCoroutines();
        IsMoving = false;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.green;
        float safeSize = Mathf.Max(0.0001f, gridSize);
        Vector3 here = transform.position;
        here.x = Mathf.Round(here.x / safeSize) * safeSize;
        here.y = Mathf.Round(here.y / safeSize) * safeSize;
        Gizmos.DrawWireCube(here, new Vector3(gridSize, gridSize, 0.1f));

        if (Application.isPlaying && !IsMoving && LastFacingDir != Vector2Int.zero)
        {
            Gizmos.color = Color.yellow;
            Vector3 next = here + (Vector3)((Vector2)LastFacingDir * gridSize);
            Gizmos.DrawWireCube(next, new Vector3(gridSize * 0.9f, gridSize * 0.9f, 0.1f));
        }
    }
}
