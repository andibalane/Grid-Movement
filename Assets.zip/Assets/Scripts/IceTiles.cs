using System.Collections;
using UnityEngine;
using UnityEngine.Tilemaps;

[CreateAssetMenu(fileName = "IceTiles", menuName = "IceTiles")]
public class IceTiles : TileBase
{
    [Header("Animation")]
    public Sprite[] iceSprites;
    public float iceSpeed = 5f;
    public float iceStartTime;

    public override void GetTileData(Vector3Int position, ITilemap tilemap, ref TileData tileData)
    {
        if (iceSprites != null && iceSprites.Length > 0)
        {
            tileData.sprite = iceSprites[0]; 
            tileData.color = Color.white;
        }
    }

    
    public override bool GetTileAnimationData(Vector3Int position, ITilemap tilemap, ref TileAnimationData tileAnimationData)
    {
        if (iceSprites != null && iceSprites.Length > 0)
        {
            tileAnimationData.animatedSprites = iceSprites;
            tileAnimationData.animationSpeed = iceSpeed;
            tileAnimationData.animationStartTime = iceStartTime;
            return true;
        }
        return false;
    }

    
    public void ApplyEffect(GridMovement player)
    {
        // Keep player sliding in their last facing direction
        if (!player.IsMoving && player.LastFacingDir != Vector2Int.zero)
        {
            if (player.CanStep(player.LastFacingDir))
            {
                player.StartCoroutine(Slide(player));
            }
            
        } 
       
    }

    private IEnumerator Slide(GridMovement player) { 
        while (player.CanStep(player.LastFacingDir))
        {

            yield return player.StartCoroutine(player.ForceMove(player.LastFacingDir));

            Vector3Int cell = player.tilemap.WorldToCell(player.transform.position);
            if (!(player.tilemap.GetTile(cell) is IceTiles))
            {
                yield break;
            }
        }
        

    }


}
