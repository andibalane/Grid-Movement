using UnityEngine;
using UnityEngine.Tilemaps;

[CreateAssetMenu(fileName = "ArrowTiles", menuName = "ArrowTiles")]
public class ArrowTiles : TileBase
{
    [Header("Animation")]
    public Sprite[] arrowSprites;
    public float arrowSpeed = 5f;
    public float arrowStartTime;

    [Header("Settings")]
    public Vector2Int forceDir = Vector2Int.up;     // Direction player will be pushed

    public override void GetTileData(Vector3Int position, ITilemap tilemap, ref TileData tileData)
    {
        if (arrowSprites != null && arrowSprites.Length > 0)
        {
            tileData.sprite = arrowSprites[0]; // 
            tileData.color = Color.white;
        }
    }

    public override bool GetTileAnimationData(Vector3Int position, ITilemap tilemap,ref TileAnimationData tileAnimationData)
    {
        if (arrowSprites != null && arrowSprites.Length > 0)
        {
            tileAnimationData.animatedSprites = arrowSprites;
            tileAnimationData.animationSpeed = arrowSpeed;
            tileAnimationData.animationStartTime = arrowStartTime;
            return true;
        }
        return false;
    }


    public void ApplyEffect(GridMovement player)
    {
        if (!player.IsMoving)
        {
            if (player.CanStep(forceDir)) 
            {
                player.StartCoroutine(player.ForceMove(forceDir));
            }
            else
            {
                player.LastFacingDir = Vector2Int.zero;
            }
        }
        

    }
}
