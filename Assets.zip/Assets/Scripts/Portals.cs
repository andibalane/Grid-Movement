using System.Collections.Generic;
using UnityEngine;

public class Portal : MonoBehaviour
{
    // Keeps track of the game objects that have entered the portal
    private HashSet<GameObject> portalObjects = new HashSet<GameObject>();

    [SerializeField] private Transform destination;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Debug.Log("Entered Portal");
        if (portalObjects.Contains(collision.gameObject))
        {
            return;
        }

        if (collision.TryGetComponent(out GridMovement mover))
        {
            mover.CancelMovement();
        }
        collision.transform.position = destination.position + destination.up * 1f; ;
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        Debug.Log("Exited Portal");
        portalObjects.Remove(collision.gameObject);
    }
}
